
let botonjunio21 = document.querySelector(".junio21");
botonjunio21.addEventListener("click", function (event) {
    junio21();

});

let botonjulio21 = document.querySelector(".julio21");
botonjulio21.addEventListener("click", function (event) {
    julio21();

});

let botonagosto21 = document.querySelector(".agosto21");
botonagosto21.addEventListener("click", function (event) {
    agosto21();

});

let botonseptiembre21 = document.querySelector(".septiembre21");
botonseptiembre21.addEventListener("click", function (event) {
    septiembre21();

});

let botonoctubre21 = document.querySelector(".octubre21");
botonoctubre21.addEventListener("click", function (event) {
    octubre21();

});

let botonnoviembre21 = document.querySelector(".noviembre21");
botonnoviembre21.addEventListener("click", function (event) {
    noviembre21();

});

let botondiciembre21 = document.querySelector(".diciembre21");
botondiciembre21.addEventListener("click", function (event) {
    diciembre21();

});

let botonEnero22 = document.querySelector(".enero22");
botonEnero22.addEventListener("click", function (event) {
    enero22();

});

let botonFebrero22 = document.querySelector(".febrero22");
botonFebrero22.addEventListener("click", function (event) {
    febrero22();
});

let botonMarzo22 = document.querySelector(".marzo22");
botonMarzo22.addEventListener("click", function (event) {
    marzo2022();
});

let botonabril22 = document.querySelector(".abril22");
botonabril22.addEventListener("click", function (event) {
    abril2022();
    console.log("Boton presionado")
});





/*Valores precargados. 
Mes actual >> Cambiar al actualizar*/

abril2022();

